import os, sqlite3, secrets
from datetime import datetime, timezone
from functools import wraps
from flask import Flask, request, jsonify, session, render_template, g
from werkzeug.middleware.proxy_fix import ProxyFix
from werkzeug.security import generate_password_hash, check_password_hash

BASE=os.path.dirname(os.path.abspath(__file__))
DATA_DIR=os.environ.get('DATA_DIR', os.path.join(BASE,'data'))
os.makedirs(DATA_DIR, exist_ok=True)
DB=os.path.join(DATA_DIR,'genaxiom.db')
app=Flask(__name__, template_folder='templates', static_folder='static')
app.wsgi_app=ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1)
app.secret_key=os.environ.get('SECRET_KEY') or secrets.token_hex(32)
app.config.update(MAX_CONTENT_LENGTH=25*1024*1024, SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE='Lax', SESSION_COOKIE_SECURE=os.environ.get('COOKIE_SECURE','1')=='1')
ADMIN_EMAIL='mariratadiwa65@gmail.com'
SETUP_TOKEN=os.environ.get('ADMIN_SETUP_TOKEN','').strip()
STATUSES=['Lead','Negotiation','Confirmed','In Progress','Completed','Cancelled']
DEPARTMENTS=['Agriculture','Construction & Real Estate','Cleaning','Training & Consultancy','General Services']

def now(): return datetime.now(timezone.utc).isoformat()
def db():
    if 'db' not in g:
        g.db=sqlite3.connect(DB); g.db.row_factory=sqlite3.Row; g.db.execute('PRAGMA foreign_keys=ON')
    return g.db
@app.teardown_appcontext
def close_db(exc):
    c=g.pop('db',None)
    if c: c.close()

def init_db():
    c=db(); c.executescript('''
    CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT,email TEXT UNIQUE NOT NULL,password_hash TEXT NOT NULL,role TEXT NOT NULL DEFAULT 'Administrator',created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS clients(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,company TEXT,phone TEXT,email TEXT,address TEXT,created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS deals(id INTEGER PRIMARY KEY AUTOINCREMENT,deal_code TEXT UNIQUE NOT NULL,client_id INTEGER NOT NULL,department TEXT,service TEXT,description TEXT,value REAL NOT NULL DEFAULT 0,status TEXT NOT NULL DEFAULT 'Lead',start_date TEXT,deadline TEXT,assigned_staff TEXT,notes TEXT,created_at TEXT NOT NULL,updated_at TEXT NOT NULL,FOREIGN KEY(client_id) REFERENCES clients(id));
    CREATE TABLE IF NOT EXISTS payments(id INTEGER PRIMARY KEY AUTOINCREMENT,deal_id INTEGER NOT NULL,amount REAL NOT NULL,method TEXT,reference TEXT,paid_at TEXT NOT NULL,FOREIGN KEY(deal_id) REFERENCES deals(id) ON DELETE CASCADE);
    CREATE TABLE IF NOT EXISTS activity(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER,action TEXT NOT NULL,entity_type TEXT,entity_id INTEGER,details TEXT,created_at TEXT NOT NULL,FOREIGN KEY(user_id) REFERENCES users(id));
    '''); c.commit()

def logged(): return bool(session.get('user_id'))
def require_login(fn):
    @wraps(fn)
    def w(*a,**kw):
        if not logged(): return jsonify(error='Authentication required'),401
        return fn(*a,**kw)
    return w

def log(action,etype=None,eid=None,details=''):
    db().execute('INSERT INTO activity(user_id,action,entity_type,entity_id,details,created_at) VALUES(?,?,?,?,?,?)',(session.get('user_id'),action,etype,eid,details,now())); db().commit()

@app.before_request
def before(): init_db()
@app.get('/')
def home(): return render_template('index.html',admin_email=ADMIN_EMAIL)
@app.get('/health')
def health(): return jsonify(status='ok',service='GenAxiom Deal Manager',version='3')

@app.get('/api/setup/status')
def setup_status():
    required=db().execute('SELECT COUNT(*) n FROM users').fetchone()['n']==0
    return jsonify(setup_required=required,admin_email=ADMIN_EMAIL,setup_token_required=bool(SETUP_TOKEN))
@app.post('/api/setup')
def setup():
    c=db()
    if c.execute('SELECT COUNT(*) n FROM users').fetchone()['n']:
        return jsonify(error='Administrator is already configured'),409
    data=request.get_json(force=True); password=data.get('password',''); confirm=data.get('confirm',''); token=(data.get('setup_token') or '').strip()
    if SETUP_TOKEN and not secrets.compare_digest(token, SETUP_TOKEN): return jsonify(error='Invalid setup token'),403
    if len(password)<8: return jsonify(error='Password must be at least 8 characters'),400
    if password!=confirm: return jsonify(error='Passwords do not match'),400
    c.execute('INSERT INTO users(email,password_hash,role,created_at) VALUES(?,?,?,?)',(ADMIN_EMAIL,generate_password_hash(password),'Administrator',now())); c.commit()
    return jsonify(ok=True,message='Administrator created securely')

@app.post('/api/login')
def login():
    data=request.get_json(force=True); email=(data.get('email') or '').strip().lower(); password=data.get('password') or ''
    u=db().execute('SELECT * FROM users WHERE lower(email)=?',(email,)).fetchone()
    if not u or not check_password_hash(u['password_hash'],password): return jsonify(error='Invalid email or password'),401
    session.clear(); session['user_id']=u['id']; session['email']=u['email']; session['role']=u['role']; log('Login'); return jsonify(email=u['email'],role=u['role'])
@app.post('/api/logout')
@require_login
def logout(): session.clear(); return jsonify(ok=True)
@app.get('/api/me')
def me(): return jsonify(logged_in=logged(),email=session.get('email'),role=session.get('role'))

@app.get('/api/dashboard')
@require_login
def dashboard():
    c=db(); value=c.execute('SELECT COALESCE(SUM(value),0) v FROM deals').fetchone()['v']; paid=c.execute('SELECT COALESCE(SUM(amount),0) v FROM payments').fetchone()['v']
    rows=c.execute('SELECT department,COUNT(*) n,COALESCE(SUM(value),0) value FROM deals GROUP BY department ORDER BY value DESC').fetchall()
    return jsonify(total_deals=c.execute('SELECT COUNT(*) n FROM deals').fetchone()['n'],active_deals=c.execute("SELECT COUNT(*) n FROM deals WHERE status NOT IN ('Completed','Cancelled')").fetchone()['n'],completed_deals=c.execute("SELECT COUNT(*) n FROM deals WHERE status='Completed'").fetchone()['n'],deal_value=value,paid=paid,outstanding=max(value-paid,0),departments=[dict(x) for x in rows])

@app.get('/api/deals')
@require_login
def deals():
    c=db(); q=request.args.get('q','').strip(); status=request.args.get('status','').strip(); sql='''SELECT d.*,c.name client,c.company,c.phone,c.email,COALESCE((SELECT SUM(amount) FROM payments p WHERE p.deal_id=d.id),0) paid FROM deals d JOIN clients c ON c.id=d.client_id WHERE 1=1'''; args=[]
    if q: sql+=' AND (d.deal_code LIKE ? OR c.name LIKE ? OR c.company LIKE ? OR d.service LIKE ?)'; args += [f'%{q}%']*4
    if status: sql+=' AND d.status=?'; args.append(status)
    sql+=' ORDER BY d.id DESC'; out=[]
    for r in c.execute(sql,args):
        x=dict(r); x['balance']=x['value']-x['paid']; out.append(x)
    return jsonify(out)

@app.post('/api/deals')
@require_login
def create_deal():
    data=request.get_json(force=True); name=(data.get('client') or '').strip()
    if not name:return jsonify(error='Client is required'),400
    try:value=float(data.get('value') or 0)
    except:return jsonify(error='Invalid contract value'),400
    if value<0:return jsonify(error='Contract value cannot be negative'),400
    status=data.get('status') or 'Lead'
    if status not in STATUSES:return jsonify(error='Invalid status'),400
    c=db(); t=now(); client=c.execute('SELECT id FROM clients WHERE name=? AND COALESCE(company,"")=?',(name,data.get('company',''))).fetchone()
    if not client:
        client=c.execute('INSERT INTO clients(name,company,phone,email,address,created_at) VALUES(?,?,?,?,?,?)',(name,data.get('company',''),data.get('phone',''),data.get('email',''),data.get('address',''),t)); client_id=client.lastrowid
    else: client_id=client['id']
    code='GA-'+datetime.now().strftime('%Y%m%d')+'-'+secrets.token_hex(3).upper()
    cur=c.execute('''INSERT INTO deals(deal_code,client_id,department,service,description,value,status,start_date,deadline,assigned_staff,notes,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)''',(code,client_id,data.get('department','General Services'),data.get('service',''),data.get('description',''),value,status,data.get('start_date',''),data.get('deadline',''),data.get('assigned_staff',''),data.get('notes',''),t,t)); c.commit(); log('Deal created','deal',cur.lastrowid,code); return jsonify(id=cur.lastrowid,deal_code=code),201

@app.get('/api/deals/<int:deal_id>')
@require_login
def deal_detail(deal_id):
    c=db(); d=c.execute('SELECT d.*,c.name client,c.company,c.phone,c.email,c.address FROM deals d JOIN clients c ON c.id=d.client_id WHERE d.id=?',(deal_id,)).fetchone()
    if not d:return jsonify(error='Deal not found'),404
    out=dict(d); out['payments']=[dict(x) for x in c.execute('SELECT * FROM payments WHERE deal_id=? ORDER BY id DESC',(deal_id,))]; out['paid']=sum(x['amount'] for x in out['payments']); out['balance']=out['value']-out['paid']; return jsonify(out)

@app.patch('/api/deals/<int:deal_id>')
@require_login
def update_deal(deal_id):
    data=request.get_json(force=True); c=db(); d=c.execute('SELECT * FROM deals WHERE id=?',(deal_id,)).fetchone()
    if not d:return jsonify(error='Deal not found'),404
    fields=['department','service','description','status','start_date','deadline','assigned_staff','notes']; vals=[data.get(k,d[k]) for k in fields]
    if vals[3] not in STATUSES:return jsonify(error='Invalid status'),400
    c.execute('UPDATE deals SET department=?,service=?,description=?,status=?,start_date=?,deadline=?,assigned_staff=?,notes=?,updated_at=? WHERE id=?',(*vals,now(),deal_id)); c.commit(); log('Deal updated','deal',deal_id,d['deal_code']); return jsonify(ok=True)

@app.post('/api/deals/<int:deal_id>/payments')
@require_login
def add_payment(deal_id):
    data=request.get_json(force=True)
    try:amount=float(data.get('amount') or 0)
    except:return jsonify(error='Invalid amount'),400
    if amount<=0:return jsonify(error='Payment must be greater than zero'),400
    c=db(); d=c.execute('SELECT value,deal_code FROM deals WHERE id=?',(deal_id,)).fetchone()
    if not d:return jsonify(error='Deal not found'),404
    paid=c.execute('SELECT COALESCE(SUM(amount),0) v FROM payments WHERE deal_id=?',(deal_id,)).fetchone()['v']
    if amount>max(d['value']-paid,0): return jsonify(error='Payment exceeds outstanding balance'),400
    cur=c.execute('INSERT INTO payments(deal_id,amount,method,reference,paid_at) VALUES(?,?,?,?,?)',(deal_id,amount,data.get('method',''),data.get('reference',''),now())); c.commit(); log('Payment received','payment',cur.lastrowid,f'{d["deal_code"]} | {amount:.2f}'); return jsonify(id=cur.lastrowid),201

@app.get('/api/payments')
@require_login
def payments(): return jsonify([dict(x) for x in db().execute('SELECT p.*,d.deal_code,c.name client FROM payments p JOIN deals d ON d.id=p.deal_id JOIN clients c ON c.id=d.client_id ORDER BY p.id DESC').fetchall()])
@app.get('/api/activity')
@require_login
def activity(): return jsonify([dict(x) for x in db().execute('SELECT a.*,u.email FROM activity a LEFT JOIN users u ON u.id=a.user_id ORDER BY a.id DESC LIMIT 100').fetchall()])

if __name__=='__main__': app.run(host='0.0.0.0',port=int(os.environ.get('PORT',5000)),debug=False)
