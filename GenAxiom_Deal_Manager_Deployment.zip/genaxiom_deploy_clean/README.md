# GenAxiom Deal Manager v3 — Cloud Deployment

Mobile-first Flask/SQLite Deal Manager for GenAxiom Network Pvt Ltd.

## Recommended cloud deployment: Render

This package is prepared for a Render web service with a persistent disk. Render's default filesystem is ephemeral, so the SQLite database is configured to live in `/data`, which must be attached as the persistent disk. A persistent disk is available on paid web services and prevents database loss across deploys/restarts. See the official Render docs for current pricing and disk limits.

### Deploy with Render Blueprint

1. Put this project in a GitHub repository.
2. In Render, create a **New Blueprint Instance** and select the repository.
3. Render reads `render.yaml` and creates the web service, persistent disk, health check, and generated `SECRET_KEY`.
4. When prompted for `ADMIN_SETUP_TOKEN`, create a separate private setup token. Do not reuse the administrator password.
5. After deployment, open the generated `onrender.com` URL.
6. On the first screen, enter the setup token and create the administrator password privately.
7. Log in with `mariratadiwa65@gmail.com` and the password you created.

### Manual Render settings

- Runtime: Python
- Build command: `pip install -r requirements.txt`
- Start command: `gunicorn --bind 0.0.0.0:$PORT --workers 1 --threads 4 --timeout 120 app:app`
- Health check: `/health`
- Persistent disk mount: `/data`
- `DATA_DIR=/data`
- `SECRET_KEY`: generate a secure secret
- `ADMIN_SETUP_TOKEN`: create a private setup token
- `COOKIE_SECURE=1`

### Important security notes

- Never commit `.env` or real secrets.
- Never put the administrator password in source code, README files, or environment variables.
- The first-run setup is protected by `ADMIN_SETUP_TOKEN` when configured.
- The administrator password is stored as a Werkzeug password hash.
- Keep HTTPS enabled through the cloud provider.
- The current database is SQLite. The deployment is intentionally single-instance (`workers=1`) because a persistent disk is attached. For future horizontal scaling, migrate the database to PostgreSQL.

## Local development

```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
python app.py
```

For local development, set `COOKIE_SECURE=0` and optionally omit `ADMIN_SETUP_TOKEN`.
